import React from 'react';
const Chat = () => {
    return (
        <div>
            <h1>Chat Room</h1>
            {/* Implement chat UI and WebSocket here */}
        </div>
    );
};

export default Chat;
